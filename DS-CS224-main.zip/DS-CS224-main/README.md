# CS224

## Introduction to Data Science

### Group Project

### PPT

https://docs.google.com/presentation/d/1RXjWLHrkDHce6-If8qvaSZ5e5GIwu3cWMNjM4B4lcf0/edit?usp=sharing

### Visualization

1. https://pawankumar2002.github.io/DS-CS224/html/visualization.html
2. https://pawankumar2002.github.io/DS-CS224/html/piechart.html

### Hypothesis Testing

1. https://pawankumar2002.github.io/DS-CS224/html/hypothesis/Clean_energy_&_sustainable_cities.html
2. https://pawankumar2002.github.io/DS-CS224/html/hypothesis/Education_vs_Gender_Equality.html
3. https://pawankumar2002.github.io/DS-CS224/html/hypothesis/Correlation_matrix.html
4. https://pawankumar2002.github.io/DS-CS224/html/hypothesis/Economic_growth_vs_Innovation.html

### Statistical Analysis

https://pawankumar2002.github.io/DS-CS224/html/statistics.html

### ML Prediction

https://pawankumar2002.github.io/DS-CS224/html/Prediction.html

#### Our Team

| Name                    | Roll No. |
| ----------------------- | -------- |
| Pawan Kumar (Team Lead) | 2001EE42 |
| Sanju Kumar             | 2001EE62 |
| Vishal Yadav            | 2001CB64 |
| Gaurav                  | 2001CB22 |
| Aaryan Dhakad           | 2001CB01 |
| Arijit Das              | 2001CB11 |
